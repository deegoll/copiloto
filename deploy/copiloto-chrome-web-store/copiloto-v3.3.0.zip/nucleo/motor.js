// copiloto-nucleo · motor de lucro (por pedido, por produto e fechamento do mês). A conta é determinística; a IA só explica.
//   receita         = Σ(preço × qtd) − desconto do vendedor            (o cupom da plataforma não entra: quem paga é o canal)
//   receita_liquida = receita − reembolso                              (devolução)
//   repasse         = receita_liquida − Σ tarifas do pedido            (estorno entra com sinal −; 'ads' não entra aqui)
//   lucro_antes_ads = repasse − custo × qtd − receita_liquida × imposto% − outros
//   lucro_real      = lucro_antes_ads − ads rateado (por anúncio e dia)
//   margem          = lucro_real / receita_liquida
// Leitura que falhou nunca vira zero: o resultado sai com status 'nao_lido' (ou 'sem_custo') e os números que dependem dela em null.
(function (root, fabrica) {
    'use strict';
    if (typeof module === 'object' && module.exports) module.exports = fabrica(require('./util'), require('./modelo'), require('./tarifas'));
    else { const CN = root.CopilotoNucleo = root.CopilotoNucleo || {}; CN.motor = fabrica(CN.util, CN.modelo, CN.tarifas); }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (U, M, T) {
    'use strict';

    const chaveItem = it => (it && (it.sku || it.anuncio_id)) || '';
    /** Valor da linha: o total que o canal deu, senão preço × qtd. null = não lido. */
    const valorItem = it => (it.total !== null && it.total !== undefined ? it.total : (it.preco_unit === null || it.preco_unit === undefined ? null : U.r2(it.preco_unit * it.qtd)));

    /**
     * Custo unitário de um SKU num dia, com vigência e kit (componentes somados, até 5 níveis).
     * custos = CustoSKU[] (chave = sku; para anúncio sem SKU o Copiloto guarda pelo id do anúncio).
     * → { custo, outros, fonte, kit } | null (sem custo informado).
     */
    function custoUnitario(custos, sku, data, nivel) {
        if (!sku || (nivel || 0) > 5) return null;
        const d = U.dia(data) || '9999-12-31';
        const cands = (custos || []).filter(c => c && c.sku === sku && (!c.vigencia_de || c.vigencia_de <= d))
            .sort((a, b) => String(b.vigencia_de || '').localeCompare(String(a.vigencia_de || '')));
        const c = cands[0];
        if (!c) return null;
        if (c.componentes && c.componentes.length) {
            let custo = 0, outros = U.num(c.outros) || 0;
            for (const comp of c.componentes) {
                const x = custoUnitario(custos, comp.sku, d, (nivel || 0) + 1);
                if (!x) return null;   // componente sem custo = kit sem custo (nunca soma parcial)
                custo += x.custo * comp.qtd; outros += x.outros * comp.qtd;
            }
            return { custo: U.r2(custo), outros: U.r2(outros), fonte: c.fonte || 'manual', kit: true };
        }
        const v = U.num(c.custo);
        return v !== null && v > 0 ? { custo: v, outros: U.num(c.outros) || 0, fonte: c.fonte || 'manual', kit: false } : null;
    }

    /** Alíquota (%) do seller para o pedido: ctx.imposto_pct fixo, ou a linha de Imposto mais recente em vigor (conta/canal). */
    function aliquota(ctx, pedido) {
        const fixo = U.num(ctx && ctx.imposto_pct);
        if (fixo !== null) return { pct: fixo, configurado: true };
        const d = pedido.data_venda;
        const cand = ((ctx && ctx.impostos) || []).filter(i => i && (!i.conta || i.conta === pedido.conta) && (!i.canal || i.canal === pedido.canal) && (!i.vigencia_de || i.vigencia_de <= d))
            .sort((a, b) => (Number(!!b.conta) + Number(!!b.canal)) - (Number(!!a.conta) + Number(!!a.canal)) || String(b.vigencia_de || '').localeCompare(String(a.vigencia_de || '')));
        return cand.length ? { pct: U.num(cand[0].aliquota_pct) || 0, configurado: true } : { pct: 0, configurado: false };
    }

    /**
     * Lucro de 1 pedido.
     * ctx = {
     *   tarifas: Tarifa[] do canal (as do pedido são filtradas por pedido_id) | naoLido | undefined (= não lido),
     *   custos: CustoSKU[], imposto_pct | impostos: Imposto[], outros: R$ extra do pedido (embalagem etc.),
     *   ads: número ou {total, porAnuncio} (de rateioAds) | naoLido | undefined (= canal não informa → 0),
     *   devolucoes: Devolucao[], estimar_tarifas: true → sem tarifa lida, estima pela tabela do canal (marcado 'estimada'),
     *   contexto_tarifa: {tipo_anuncio, frete_gratis_programa, ...} (para a estimativa), margem_alvo_pct, tabela
     * }
     */
    function lucroPedido(pedido, ctx) {
        ctx = ctx || {};
        const avisos = [], faltando = [];
        const base = { pedido_id: pedido && pedido.id, canal: pedido && pedido.canal, conta: pedido && pedido.conta, data: pedido && pedido.data_venda };
        if (M.ehNaoLido(pedido)) return Object.assign(base, { status: 'nao_lido', faltando: ['pedido'], motivo: pedido.motivo, avisos });
        const erros = M.validar('pedido', pedido);
        if (erros.length) return Object.assign(base, { status: 'nao_lido', faltando: ['pedido'], motivo: 'pedido inválido: ' + erros.join('; '), avisos });
        const cancelado = pedido.status === 'cancelado';

        // ── Receita ──
        if (pedido.itens.some(it => valorItem(it) === null)) faltando.push('preco');
        const bruto = cancelado ? 0 : U.soma(pedido.itens, it => (valorItem(it) || 0));
        const desconto = cancelado ? 0 : (pedido.desconto_vendedor || 0);
        const receita = U.r2(bruto - desconto);
        const devs = (ctx.devolucoes || []).filter(d => d && d.pedido_id === pedido.id);
        const reembDevs = U.soma(devs, d => d.valor_reembolsado);
        const reembolso = cancelado ? 0 : Math.min(receita, Math.max(pedido.reembolso || 0, reembDevs));
        const receitaLiq = U.r2(receita - reembolso);
        const reembolsoTotal = !cancelado && reembolso > 0 && reembolso >= receita - 0.01;

        // ── Tarifas ──
        let tarifas = null, estimadas = false;
        const lidas = ctx.tarifas;
        if (Array.isArray(lidas)) tarifas = lidas.filter(t => t && t.pedido_id === pedido.id);
        else if (ctx.estimar_tarifas && !faltando.length) {
            tarifas = [];
            pedido.itens.forEach(it => {
                const unit = it.qtd > 0 ? ((valorItem(it) || 0) - desconto * ((valorItem(it) || 0)) / (bruto || 1)) / it.qtd : 0;
                const ls = T.tarifasDoItem(pedido.canal, unit, Object.assign({}, ctx.contexto_tarifa || {}, { qtd: it.qtd }), pedido.data_venda, ctx.tabela);
                if (!ls) { faltando.push('tabela_tarifa'); return; }
                ls.forEach(l => tarifas.push({ tipo: l.tipo, valor: l.valor, pedido_id: pedido.id, anuncio_id: it.anuncio_id, estimada: true, texto_original: 'tabela: ' + l.regra }));
            });
            estimadas = true;
            avisos.push('tarifas estimadas pela tabela do canal (não lidas)');
        } else faltando.push('tarifas');
        if (tarifas && cancelado === false && reembolsoTotal) {
            // Com reembolso total o canal pode não cobrar comissão/fixo (TikTok): vale o que foi LIDO. Estimativa: só o que fica (programa de frete).
            if (estimadas) tarifas = tarifas.filter(t => t.tipo === 'programa_frete');
        }
        // Frete de volta que veio só na Devolucao (sem a tarifa no pedido) entra como frete_devolucao.
        if (tarifas && !tarifas.some(t => t.tipo === 'frete_devolucao')) devs.forEach(d => { if (d.frete_volta > 0) tarifas.push({ tipo: 'frete_devolucao', valor: d.frete_volta, pedido_id: pedido.id, texto_original: 'frete de volta (devolução)' }); });

        const porTipo = {};
        let adsDoPedido = 0;
        (tarifas || []).forEach(t => {
            if (t.tipo === 'ads') { adsDoPedido = U.r2(adsDoPedido + t.valor); return; }
            porTipo[t.tipo] = U.r2((porTipo[t.tipo] || 0) + t.valor);
            if (t.estimada) estimadas = true;
        });
        const tarifasRs = tarifas ? U.soma(Object.keys(porTipo), k => porTipo[k]) : null;
        const repasse = tarifas && !faltando.length ? U.r2(receitaLiq - tarifasRs) : null;   // falta preço ou tabela = sem repasse

        // ── Custo (SKU e kit) ──
        const semCusto = [], custoPorSku = {};
        let custo = 0, outrosSku = 0;
        const produtoVoltou = devs.map(d => d.produto_voltou).find(v => v === true || v === false);
        const custoZero = cancelado || (reembolsoTotal && produtoVoltou === true);
        if (reembolsoTotal && produtoVoltou === undefined) avisos.push('reembolso total sem saber se o produto voltou: o custo do produto foi contado');
        pedido.itens.forEach(it => {
            const k = chaveItem(it), c = custoUnitario(ctx.custos, k, pedido.data_venda);
            if (!c) { if (!cancelado) semCusto.push(k || '(sem SKU)'); return; }
            const v = custoZero ? 0 : U.r2(c.custo * it.qtd), o = custoZero ? 0 : U.r2(c.outros * it.qtd);
            custoPorSku[k] = U.r2((custoPorSku[k] || 0) + v);
            custo += v; outrosSku += o;
        });
        custo = U.r2(custo);

        // ── Imposto, outros, ads ──
        const al = aliquota(ctx, pedido);
        if (!al.configurado) avisos.push('imposto não configurado: contado como 0%');
        const imposto = U.r2(receitaLiq * al.pct / 100);
        const outros = U.r2(outrosSku + (U.num(ctx.outros) || 0));
        let adsRs = adsDoPedido, adsPorAnuncio = {};
        if (M.ehNaoLido(ctx.ads)) faltando.push('ads');
        else if (typeof ctx.ads === 'number') adsRs = U.r2(adsRs + ctx.ads);
        else if (ctx.ads && typeof ctx.ads === 'object') { adsRs = U.r2(adsRs + (U.num(ctx.ads.total) || 0)); adsPorAnuncio = ctx.ads.porAnuncio || {}; }

        const lucroAntesAds = repasse !== null && !semCusto.length ? U.r2(repasse - custo - imposto - outros) : null;
        const lucroReal = lucroAntesAds !== null && !faltando.includes('ads') ? U.r2(lucroAntesAds - adsRs) : null;
        const margem = lucroReal !== null && receitaLiq > 0 ? Math.round(lucroReal / receitaLiq * 10000) / 100 : null;
        const alvo = U.num(ctx.margem_alvo_pct) || 0;
        const status = faltando.length ? 'nao_lido' : (semCusto.length ? 'sem_custo' : (cancelado ? 'cancelado' : 'ok'));

        // Rateio por item (para o lucro por produto): custo exato; o resto pela participação do item na receita bruta.
        const porItem = pedido.itens.map(it => {
            const k = chaveItem(it), part = bruto > 0 ? (valorItem(it) || 0) / bruto : 1 / pedido.itens.length;
            const mesmos = pedido.itens.filter(x => x.anuncio_id && x.anuncio_id === it.anuncio_id);
            const partAnuncio = mesmos.length > 1 ? ((valorItem(it) || 0)) / (U.soma(mesmos, x => (valorItem(x) || 0)) || 1) : 1;
            const adsItem = it.anuncio_id && adsPorAnuncio[it.anuncio_id] !== undefined ? U.r2(adsPorAnuncio[it.anuncio_id] * partAnuncio) : U.r2((adsRs - U.soma(Object.keys(adsPorAnuncio), a => adsPorAnuncio[a])) * part);
            const c = custoUnitario(ctx.custos, k, pedido.data_venda);
            return { sku: k, anuncio_id: it.anuncio_id, qtd: it.qtd, participacao: part,
                receita: U.r2(receitaLiq * part), tarifas: tarifasRs === null ? null : U.r2(tarifasRs * part),
                custo: c ? (custoZero ? 0 : U.r2(c.custo * it.qtd)) : null, outros: U.r2(outros * part), imposto: U.r2(imposto * part), ads: adsItem };
        });

        const linhas = [];
        if (!cancelado) {
            linhas.push({ rotulo: 'Venda (preço × qtd)', valor: bruto, de: 'canal' });
            if (desconto) linhas.push({ rotulo: 'Desconto pago por você', valor: -desconto, de: 'canal' });
            if (reembolso) linhas.push({ rotulo: 'Reembolso ao comprador', valor: -reembolso, de: 'canal' });
        }
        Object.keys(porTipo).forEach(k => linhas.push({ rotulo: 'Tarifa: ' + k + (estimadas ? ' (estimada)' : ''), valor: -porTipo[k], de: 'canal' }));
        if (repasse !== null) linhas.push({ rotulo: '= Repasse do canal', valor: repasse, de: 'canal', total: true });
        if (custo || semCusto.length) linhas.push({ rotulo: 'Custo do produto', valor: semCusto.length ? null : -custo, de: 'seller' });
        if (outros) linhas.push({ rotulo: 'Outros custos', valor: -outros, de: 'seller' });
        linhas.push({ rotulo: 'Imposto (' + String(al.pct).replace('.', ',') + '%)', valor: -imposto, de: 'seller' });
        if (lucroAntesAds !== null) linhas.push({ rotulo: '= Lucro antes do Ads', valor: lucroAntesAds, de: 'seller', total: true });
        if (adsRs) linhas.push({ rotulo: 'Ads (rateado)', valor: -adsRs, de: 'seller' });
        if (lucroReal !== null) linhas.push({ rotulo: lucroReal < 0 ? '= Prejuízo' : '= Lucro', valor: lucroReal, de: 'seller', total: true });

        return Object.assign(base, {
            status, faltando, sem_custo: semCusto, avisos,
            bruto, desconto_vendedor: desconto, receita, reembolso, receita_liquida: receitaLiq,
            tarifas_por_tipo: porTipo, tarifas_rs: tarifasRs, tarifas_estimadas: estimadas, repasse,
            custo_rs: semCusto.length ? null : custo, custo_por_sku: custoPorSku, outros_rs: outros,
            imposto_pct: al.pct, imposto_rs: imposto, lucro_antes_ads: lucroAntesAds, ads_rs: faltando.includes('ads') ? null : adsRs,
            lucro_real: lucroReal, margem_pct: margem,
            classe: lucroReal === null ? status : (lucroReal < 0 ? 'prejuizo' : (margem !== null && margem < alvo ? 'apertado' : 'lucrativo')),
            por_item: porItem, linhas,
        });
    }

    /**
     * Rateio do Ads por anúncio e dia: o custo de (anúncio, dia) vai para os pedidos daquele anúncio naquele dia, pela receita do item.
     * Entrada por período (periodo_de/periodo_ate) vale para os pedidos do anúncio no período. Custo sem venda (ou sem anuncio_id)
     * fica em naoRateado — vai para o fechamento do mês, nunca some.
     * → { porPedido: {pedido_id: {total, porAnuncio: {anuncio_id: valor}}}, naoRateado: Ads[], total_rateado, total_nao_rateado }
     */
    function rateioAds(ads, pedidos) {
        const porPedido = {}, naoRateado = [];
        let totR = 0, totN = 0;
        const validos = (pedidos || []).filter(p => p && !M.ehNaoLido(p) && p.status !== 'cancelado' && Array.isArray(p.itens));
        (ads || []).forEach(a => {
            if (!a || !(a.custo > 0)) return;
            const noDia = p => (a.dia ? p.data_venda === a.dia : (a.periodo_de && a.periodo_ate && p.data_venda >= a.periodo_de && p.data_venda <= a.periodo_ate));
            const alvo = [];
            if (a.anuncio_id) validos.forEach(p => { if (!noDia(p)) return; const peso = U.soma(p.itens.filter(it => it.anuncio_id === a.anuncio_id), it => (valorItem(it) || 0)); if (peso > 0) alvo.push({ p, peso }); });
            const somaPeso = U.soma(alvo, x => x.peso);
            if (!alvo.length || !(somaPeso > 0)) { naoRateado.push(a); totN += a.custo; return; }
            let resto = U.r2(a.custo);
            alvo.forEach((x, i) => {
                const v = i === alvo.length - 1 ? resto : U.r2(a.custo * x.peso / somaPeso);   // o último leva o centavo que sobra
                resto = U.r2(resto - v);
                const e = porPedido[x.p.id] || (porPedido[x.p.id] = { total: 0, porAnuncio: {} });
                e.total = U.r2(e.total + v);
                e.porAnuncio[a.anuncio_id] = U.r2((e.porAnuncio[a.anuncio_id] || 0) + v);
            });
            totR += a.custo;
        });
        return { porPedido, naoRateado, total_rateado: U.r2(totR), total_nao_rateado: U.r2(totN) };
    }

    /**
     * Lucro por produto: SKU normalizado × canal × conta, e × mês com porMes = true (3.3.0, E4; sem SKU, pelo id do anúncio). Soma:
     *   - os resultados do lucroPedido (por_item; o mês é o da venda);
     *   - as linhas "mês × anúncio" do ML (adaptadores.ml.produtosDoMes: o mês é o delas; pedidos = quantidade de vendas do mês).
     * Sem porMes, soma o período que veio, como sempre (o SHC.tt.porProduto usa assim).
     * Só entram os 'ok' e 'cancelado'; os outros contam em pendentes (o painel mostra "N pedidos sem custo / não lidos"). Com pendentes > 0,
     * o lucro_antes_ads é só o das linhas com conta, não o total do SKU (o SHC.familias dá null): a tela confere os pendentes antes de mostrar.
     * As linhas do ML somam o lucro sem arredondar (lucro_antes_ads_exato) e arredondam só no SKU, como o SHC.familias (mesmo centavo).
     * Ads "—" em alguma linha (o ML sem o Ads do anúncio na fatura) → ads e lucro_real null; o lucro_antes_ads continua.
     */
    function lucroPorProduto(resultados, porMes) {
        const g = {};
        (resultados || []).forEach(r => {
            const doMes = !r.por_item && !!r.mes, mes = !porMes ? null : doMes ? r.mes : U.mes(r.data);
            const itens = doMes ? [{ sku: r.sku || r.anuncio_id, qtd: r.unidades, receita: r.bruto, tarifas: U.r2((r.tarifa || 0) + (r.frete || 0)), custo: r.custo,
                outros: r.outros || 0, imposto: r.imposto || 0, ads: r.ads, antes: r.lucro_antes_ads_exato !== undefined ? r.lucro_antes_ads_exato : r.lucro_antes_ads }] : (r.por_item || []);
            itens.forEach(x => {
                const k = [r.canal, r.conta, mes, U.normalizaSku(x.sku)].join('|');
                const s = g[k] || (g[k] = { sku: x.sku, canal: r.canal || null, conta: r.conta || '', mes, pedidos: 0, unidades: 0, receita: 0, tarifas: 0, custo: 0, outros: 0,
                    imposto: 0, ads: 0, lucro_antes_ads: 0, lucro_real: 0, pendentes: 0, pedidos_ids: [] });
                if (r.status !== 'ok' && r.status !== 'cancelado') { s.pendentes++; return; }
                if (doMes) s.pedidos += r.vendas || 0;
                else if (s.pedidos_ids.indexOf(r.pedido_id) < 0) { s.pedidos_ids.push(r.pedido_id); s.pedidos++; }
                if (r.status === 'ok') s.unidades += x.qtd;
                const antes = x.antes !== undefined ? x.antes : x.receita - (x.tarifas || 0) - (x.custo || 0) - x.outros - x.imposto;
                s.receita += x.receita; s.tarifas += x.tarifas || 0; s.custo += x.custo || 0; s.outros += x.outros; s.imposto += x.imposto; s.lucro_antes_ads += antes;
                if (x.ads === null || s.ads === null) { s.ads = null; s.lucro_real = null; }   // não lido nunca vira zero
                else { s.ads += x.ads; s.lucro_real += antes - x.ads; }
            });
        });
        return Object.keys(g).map(k => {
            const s = g[k];
            ['receita', 'tarifas', 'custo', 'outros', 'imposto', 'ads', 'lucro_antes_ads', 'lucro_real'].forEach(c => { s[c] = U.r2(s[c]); });
            s.margem_pct = s.lucro_real !== null && s.receita > 0 ? Math.round(s.lucro_real / s.receita * 10000) / 100 : null;
            delete s.pedidos_ids;
            return s;
        }).sort((a, b) => b.receita - a.receita);
    }

    /**
     * Fechamento do mês ('AAAA-MM'): pedidos + tarifas SEM pedido (fatura, Full, assinatura…) + Ads que não deu para ratear.
     * ads_rateados = true (padrão): as tarifas 'ads' sem pedido NÃO entram (o Ads já foi pelo rateio + naoRateado — não contar 2 vezes).
     * ads_nas_tarifas = false (3.3.0: canal que NÃO traz o Ads nas tarifas — só o TikTok): o Ads do mês vem de ads_mes (campo manual; 0 = "não uso").
     *   Sem ads_mes o mês sai com aprox: true ("≈") e o motivo, e o lucro fica sem o Ads: Ads não lido nunca vira zero calado.
     *   No ML o Ads vem na fatura (padrão, ads_nas_tarifas diferente de false): a regra não se aplica e o mês nunca ganha "≈" por isso.
     * → { mes, pedidos, receita_liquida, repasse, lucro_pedidos, sem_pedido: {porTipo, total, estornos}, ads_nao_rateado, ads_mes, lucro_mes, completo,
     *     pendentes, aprox, motivo }
     */
    function fechamentoMes(o) {
        o = o || {};
        const mes = o.mes, dentro = d => U.mes(d) === mes;
        const res = (o.resultados || []).filter(r => dentro(r.data));
        const conta = res.filter(r => r.status === 'ok' || r.status === 'cancelado');
        const porTipo = {};
        let estornos = 0;
        const tarifas = Array.isArray(o.tarifas) ? o.tarifas : [];
        tarifas.forEach(t => {
            if (!t || t.pedido_id || !dentro(t.data)) return;
            if (t.tipo === 'ads' && o.ads_rateados !== false) return;
            porTipo[t.tipo] = U.r2((porTipo[t.tipo] || 0) + t.valor);
            if (t.valor < 0) estornos = U.r2(estornos + t.valor);
        });
        const semPedido = U.soma(Object.keys(porTipo), k => porTipo[k]);
        const adsN = U.soma((o.adsNaoRateado || []).filter(a => dentro(a.dia || a.periodo_ate)), a => a.custo);
        const lucroPedidos = U.soma(conta, r => r.lucro_real);
        const adsMes = o.ads_nas_tarifas === false ? U.num(o.ads_mes) : null, semAds = o.ads_nas_tarifas === false && adsMes === null;
        return {
            mes, pedidos: conta.length, pendentes: res.length - conta.length,
            receita_liquida: U.soma(conta, r => r.receita_liquida), repasse: U.soma(conta, r => r.repasse),
            custo: U.soma(conta, r => r.custo_rs), imposto: U.soma(conta, r => r.imposto_rs), ads_rateado: U.soma(conta, r => r.ads_rs),
            lucro_pedidos: lucroPedidos, sem_pedido: { porTipo, total: semPedido, estornos }, ads_nao_rateado: adsN, ads_mes: adsMes,
            lucro_mes: U.r2(lucroPedidos - semPedido - adsN - (adsMes || 0)),
            completo: res.length === conta.length && !M.ehNaoLido(o.tarifas),
            aprox: semAds, motivo: semAds ? 'Ads não informado' : '',
        };
    }

    // o "faltando" do mês (ids internos) no texto da tela
    const FALTA = { vendas_brutas: 'vendas brutas', faturamento: 'faturamento', custo_produtos: 'custo dos produtos', imposto: 'imposto' };
    /**
     * Soma dos canais ("Todos", 3.3.0): o total e o % de cada canal numa conta só (valor ÷ total, 1 casa: o mesmo % do filtro do canal).
     * meses = [{ canal, conta?, aprox?, motivo?, faltando?, [campo]: número | null }] (ex.: ml.mesDaCascata + o mês do TikTok); campo = 'lucro'.
     * Canal com "≈" (aprox) põe "≈" no total. Canal sem número fica fora da soma e o total leva "≈" com o motivo. Nenhum número → total null.
     * % só com total > 0 (prejuízo não se rateia em %).
     * → { total, aprox, motivos:[{canal, conta, motivo}], canais:[{canal, conta, valor, pct, aprox}] }
     */
    function somaCanais(meses, campo) {
        const k = campo || 'lucro', motivos = [];
        const canais = (meses || []).filter(Boolean).map(m => {
            const valor = U.num(m[k]), aprox = !!m.aprox || valor === null;
            if (aprox) motivos.push({ canal: m.canal, conta: m.conta || '', motivo: m.motivo || (valor !== null ? 'valor aproximado'
                : m.faltando && m.faltando.length ? 'falta: ' + m.faltando.map(f => FALTA[f] || f).join(', ') : 'não lido') });
            return { canal: m.canal, conta: m.conta || '', valor, aprox };
        });
        const com = canais.filter(c => c.valor !== null), total = com.length ? U.soma(com, c => c.valor) : null;
        canais.forEach(c => { c.pct = c.valor !== null && total > 0 ? Math.round(c.valor / total * 1000) / 10 + 0 : null; });   // + 0: sem −0
        return { total, aprox: motivos.length > 0, motivos, canais };
    }

    return { custoUnitario, aliquota, lucroPedido, rateioAds, lucroPorProduto, fechamentoMes, somaCanais };
});
